package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.Keys;


 public class HomePage extends BasePage {
    @FindBy(name = "query")
    private WebElement searchInput;

    @FindBy(css = "button.btn-search")
    private WebElement searchButton;

    @FindBy(css = ".popular-suggestions a.nav-link")
    private WebElement popularSuggestions;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void open() {
        driver.get("https://demo5.cybersoft.edu.vn/");
        wait.until(ExpectedConditions.visibilityOf(searchInput));
        LOGGER.info("Opened Home Page.");
    }

    public void enterSearchKeyword(String keyword) {
        searchInput.sendKeys(keyword);
        LOGGER.info("Entered keyword: " + keyword);
    }

    public void pressEnterInSearchBox() {
        searchInput.sendKeys(Keys.ENTER);
        LOGGER.info("Pressed Enter in search box.");
    }

    public void clickSearchButton() {
        searchButton.click();
        LOGGER.info("Clicked search button.");
    }

    public String getSearchInputPlaceholder() {
        return searchInput.getAttribute("placeholder");
    }

    public boolean isSearchInputFocused() {
        return searchInput.equals(driver.switchTo().activeElement());
    }

    public void clickPopularSuggestion() {
        popularSuggestions.click();
    }
}