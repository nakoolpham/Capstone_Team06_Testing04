package tests;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.openqa.selenium.WebDriver;
import utils.ScreenshotUtils;

public class TestListener extends BaseTest implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        // Lấy driver từ BaseTest
        WebDriver driver = this.driver;
        String testName = result.getName();

        // Gọi ScreenshotUtils để chụp hình
        String screenshotPath = ScreenshotUtils.takeScreenshot(driver, testName);
        System.out.println("❌ Test Failed: " + testName);
        System.out.println("📸 Screenshot saved at: " + screenshotPath);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("✅ Test Passed: " + result.getName());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("⚠️ Test Skipped: " + result.getName());
    }

    @Override
    public void onStart(ITestContext context) {}

    @Override
    public void onFinish(ITestContext context) {}
}
