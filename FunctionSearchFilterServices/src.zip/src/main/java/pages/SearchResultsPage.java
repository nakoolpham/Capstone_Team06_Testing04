package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SearchResultsPage extends BasePage {
    private static final Logger LOGGER = Logger.getLogger(SearchResultsPage.class.getName());

    @FindBy(css = ".card")
    private List<WebElement> serviceItems;

    @FindBy(xpath = "//p[contains(text(), 'Sorry, we couldn’t find any matches.')]")
    private WebElement noResultsMessage;

    @FindBy(css = "div.ant-tabs-nav")
    private WebElement categoriesTabs;

    @FindBy(xpath = "//div[contains(text(),'Sort by')]")
    private WebElement sortByDropdown;

    @FindBy(css = "div.ant-dropdown-menu-item")
    private List<WebElement> sortByOptions;

    @FindBy(xpath = "//span[contains(text(), 'Online sellers')]/preceding-sibling::span[@class='ant-switch']")
    private WebElement onlineSellersCheckbox;

    @FindBy(xpath = "//span[contains(text(), 'Pro services')]/preceding-sibling::span[@class='ant-switch']")
    private WebElement proServicesCheckbox;

    @FindBy(xpath = "//span[contains(text(), 'Local sellers')]/preceding-sibling::span[@class='ant-switch']")
    private WebElement localSellersCheckbox;

    public SearchResultsPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        this.wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);  // 🔑 bắt buộc để init @FindBy
    }

    public boolean areServiceItemsDisplayed() {
        try {
            wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".card")));
            return !serviceItems.isEmpty();
        } catch (Exception e) {
            LOGGER.warning("No service items found.");
            return false;
        }
    }

    public boolean isNoResultsMessageDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOf(noResultsMessage));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getFirstServiceTitle() {
        wait.until(ExpectedConditions.visibilityOfAllElements(serviceItems));
        return serviceItems.get(0).findElement(By.cssSelector("h5")).getText();
    }

    public void clickCategoriesTab(String tabName) {
        By tabLocator = By.xpath(String.format("//div[@role='tab'][contains(text(), '%s')]", tabName));
        wait.until(ExpectedConditions.elementToBeClickable(tabLocator)).click();
        LOGGER.info("Clicked category tab: " + tabName);
    }

    public void clickCheckbox(String checkboxName) {
        switch (checkboxName) {
            case "Pro services":
                wait.until(ExpectedConditions.elementToBeClickable(proServicesCheckbox)).click();
                break;
            case "Local sellers":
                wait.until(ExpectedConditions.elementToBeClickable(localSellersCheckbox)).click();
                break;
            case "Online sellers":
                wait.until(ExpectedConditions.elementToBeClickable(onlineSellersCheckbox)).click();
                break;
            default:
                LOGGER.log(Level.WARNING, "Checkbox not found: " + checkboxName);
        }
    }

    public boolean isCheckboxSelected(String checkboxName) {
        switch (checkboxName) {
            case "Pro services":
                return proServicesCheckbox.getAttribute("class").contains("ant-switch-checked");
            case "Local sellers":
                return localSellersCheckbox.getAttribute("class").contains("ant-switch-checked");
            case "Online sellers":
                return onlineSellersCheckbox.getAttribute("class").contains("ant-switch-checked");
            default:
                return false;
        }
    }

    public void clickSortByDropdown() {
        wait.until(ExpectedConditions.elementToBeClickable(sortByDropdown)).click();
    }

    public void selectSortByOption(String option) {
        By optionLocator = By.xpath(String.format("//li[contains(text(), '%s')]", option));
        wait.until(ExpectedConditions.elementToBeClickable(optionLocator)).click();
        LOGGER.info("Selected sort option: " + option);
    }

    public String getDropdownMenuClass() {
        return sortByDropdown.getAttribute("class");
    }
}
