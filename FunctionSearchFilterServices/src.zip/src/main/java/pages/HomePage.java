package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.Keys;

import java.time.Duration;
import java.util.logging.Logger;

public class HomePage extends BasePage {
    private static final Logger LOGGER = Logger.getLogger(HomePage.class.getName());

    @FindBy(css = "input[placeholder*='Tìm kiếm'], input[placeholder*='Try']")
    private WebElement searchInput;

    @FindBy(css = "button.btn-search")
    private WebElement searchButton;

    @FindBy(css = ".popular-suggestions a.nav-link")
    private WebElement popularSuggestions;

    public HomePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        this.wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);   // 🔑 Quan trọng
    }

    public void open() {
        driver.get("https://demo5.cybersoft.edu.vn/");
        wait.until(ExpectedConditions.visibilityOf(searchInput));
        LOGGER.info("Opened Home Page.");
    }

    public void enterSearchKeyword(String keyword) {
        searchInput.clear();
        searchInput.sendKeys(keyword);
        LOGGER.info("Entered keyword: " + keyword);
    }

    public void pressEnterInSearchBox() {
        searchInput.sendKeys(Keys.ENTER);
        LOGGER.info("Pressed Enter in search box.");
    }

    public void clickSearchButton() {
        wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();
        // 🔑 Chờ dấu hiệu đặc trưng của trang SearchResults xuất hiện
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.presenceOfElementLocated(By.cssSelector(".card")),
                    ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//p[contains(text(), 'Sorry, we couldn’t find any matches.')]")
                    )
            ));
            LOGGER.info("Clicked search button and search results loaded.");
        } catch (Exception e) {
            LOGGER.warning("Search results page did not load as expected.");
        }
    }


    public String getSearchInputPlaceholder() {
        return searchInput.getAttribute("placeholder");
    }

    public boolean isSearchInputFocused() {
        return searchInput.equals(driver.switchTo().activeElement());
    }

    public void clickPopularSuggestion() {
        wait.until(ExpectedConditions.elementToBeClickable(popularSuggestions));
        popularSuggestions.click();
        LOGGER.info("Clicked popular suggestion.");
    }

    public void clickSearchInput() {
        WebElement input = wait.until(ExpectedConditions.elementToBeClickable(searchInput));
        input.click();
        LOGGER.info("Clicked on search input.");
    }
}
