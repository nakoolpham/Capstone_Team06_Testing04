package tests;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import org.testng.Assert;

import java.util.logging.Logger;

public class SearchAndFilterTest extends BaseTest {
    private static final Logger LOGGER = Logger.getLogger(SearchAndFilterTest.class.getName());

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;

    @BeforeMethod
    public void setUpPage() {
        homePage = new HomePage(driver);
        homePage.open();
    }

    // Nhóm 1: Test các chức năng tìm kiếm cơ bản
    //------------------------------------------------------------------------------------------------------------------------------------

    @Test(testName = "TC001_VerifySearchBarUI")
    public void testSearchBarUI() {

        String placeholder = homePage.getSearchInputPlaceholder();
        Assert.assertTrue(
                placeholder.contains("Try") || placeholder.contains("Tìm kiếm"),
                "Placeholder is not correct. Actual: " + placeholder
        );
        homePage.clickSearchInput();
        LOGGER.info("Test passed: Search bar UI is correct (placeholder + clickable).");
    }

    @Test(testName = "TC002_VerifySearchWithValidKeyword")
    public void testSearchWithValidKeyword() {
        homePage.enterSearchKeyword("Logo Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchResultsPage.areServiceItemsDisplayed(), "Service list should be displayed.");
        Assert.assertTrue(searchResultsPage.getFirstServiceTitle().contains("Logo Design"),
                "Search results are not relevant.");
        LOGGER.info("✅ Search with valid keyword returns corresponding results.");
    }

    @Test(testName = "TC003_TC004_VerifySearchWithCaseSensitivity")
    public void testSearchWithCaseSensitivity() {
        homePage.enterSearchKeyword("LOGO");
        homePage.clickSearchButton();
        searchResultsPage = new SearchResultsPage(driver);
        String firstTitle1 = searchResultsPage.getFirstServiceTitle();

        homePage.open();
        homePage.enterSearchKeyword("logo");
        homePage.clickSearchButton();
        searchResultsPage = new SearchResultsPage(driver);
        String firstTitle2 = searchResultsPage.getFirstServiceTitle();

        Assert.assertEquals(firstTitle1, firstTitle2,
                "Results for uppercase and lowercase queries should be the same.");
        LOGGER.info("✅ Search is not case sensitive.");
    }

    @Test(testName = "TC005_VerifySearchWithSpecialCharacters")
    public void testSearchWithSpecialCharacters() {
        homePage.enterSearchKeyword("@#$%");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchResultsPage.isNoResultsMessageDisplayed(),
                "No results message should be displayed.");
        LOGGER.info("✅ Search with special characters handled gracefully.");
    }

    @Test(testName = "TC006_VerifySearchWithEmptyInput")
    public void testSearchWithEmptyInput() {
        homePage.clickSearchButton();

        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.endsWith("/"), "URL should not change.");
        LOGGER.info("✅ Empty search input handled gracefully.");
    }

    @Test(testName = "TC007_VerifySearchWithVeryLongString")
    public void testSearchWithVeryLongString() {
        homePage.enterSearchKeyword("thisisalongstringofmorethan255charactersthatshouldbeprop");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchResultsPage.isNoResultsMessageDisplayed(),
                "Very long string should be handled gracefully.");
        LOGGER.info("✅ Very long string is handled gracefully.");
    }

    @Test(testName = "TC008_VerifySearchWithLeadingTrailingSpaces")
    public void testSearchWithLeadingTrailingSpaces() {
        homePage.enterSearchKeyword("   logo   ");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchResultsPage.areServiceItemsDisplayed(),
                "Results should be displayed for trimmed keyword.");
        LOGGER.info("✅ Leading/trailing spaces are trimmed.");
    }

    @Test(testName = "TC009_VerifySearchWithNonEnglishCharacters")
    public void testSearchWithNonEnglishCharacters() {
        homePage.enterSearchKeyword("Thiết kế");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        Assert.assertTrue(searchResultsPage.isNoResultsMessageDisplayed(),
                "Non-English characters should return no results.");
        LOGGER.info("✅ Non-English characters are handled.");
    }

    @Test(testName = "TC010_VerifyPopularRecommend")
    public void testPopularRecommend() {
        homePage.clickPopularSuggestion();
        Assert.assertFalse(driver.getCurrentUrl().contains("result"),
                "Popular suggestions should NOT redirect to search results.");
        LOGGER.info("✅ Popular suggestions handled correctly.");
    }

    // Nhóm 2: Test các chức năng lọc và sắp xếp
    //------------------------------------------------------------------------------------------------------------------------------------

    @Test(testName = "TC011_TC017_VerifyCategoriesTabsAndOptions")
    public void testCategoriesTabsAndOptions() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCategoriesTab("Graphics & Design");

        LOGGER.info("✅ Categories tabs are clickable and dropdowns appear.");
    }

    @Test(testName = "TC018_VerifyFilterBoxesDisplayed")
    public void testFilterBoxesDisplayed() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        Assert.assertFalse(driver.getCurrentUrl().contains("categories="),
                "Categories filter is not applied yet.");
        LOGGER.info("✅ Filter boxes are displayed as expected.");
    }

    @Test(testName = "TC019_VerifyCategoriesFields")
    public void testCategoriesFields() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCategoriesTab("Graphics & Design");

        Assert.assertFalse(driver.getCurrentUrl().contains("category="),
                "Filter is not applied as expected.");
        LOGGER.info("✅ Verified: Categories dropdown fields currently not applying filter (bug).");
    }

    @Test(testName = "TC020_VerifyServiceOptionsFields")
    public void testServiceOptionsFields() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        Assert.assertFalse(driver.getCurrentUrl().contains("service_option"),
                "Filter is not applied as expected.");
        LOGGER.info("✅ Verified: Service Options dropdown fields currently not applying filter (bug).");
    }

    @Test(testName = "TC021_VerifySellerDetailsFields")
    public void testSellerDetailsFields() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        Assert.assertFalse(driver.getCurrentUrl().contains("seller_detail"),
                "Filter is not applied as expected.");
        LOGGER.info("✅ Verified: Seller Details dropdown fields currently not applying filter (bug).");
    }

    @Test(testName = "TC022_VerifyDeliveryTimeFields")
    public void testDeliveryTimeFields() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        Assert.assertFalse(driver.getCurrentUrl().contains("delivery_time"),
                "Filter is not applied as expected.");
        LOGGER.info("✅ Verified: Delivery Time dropdown fields currently not applying filter (bug).");
    }

    @Test(testName = "TC023_VerifyProServicesCheckbox")
    public void testProServicesCheckbox() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCheckbox("Pro services");

        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Pro services"),
                "Pro services checkbox is not selected.");
        Assert.assertFalse(driver.getCurrentUrl().contains("pro_services"),
                "URL should not be filtered by Pro services (bug).");
        LOGGER.info("✅ Verified: Pro services checkbox selection does not apply filter (bug).");
    }

    @Test(testName = "TC024_VerifyLocalSellersCheckbox")
    public void testLocalSellersCheckbox() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCheckbox("Local sellers");

        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Local sellers"),
                "Local sellers checkbox is not selected.");
        Assert.assertFalse(driver.getCurrentUrl().contains("local_sellers"),
                "URL should not be filtered by Local sellers (bug).");
        LOGGER.info("✅ Verified: Local sellers checkbox selection does not apply filter (bug).");
    }

    @Test(testName = "TC025_VerifyOnlineSellersCheckbox")
    public void testOnlineSellersCheckbox() {
        homePage.enterSearchKeyword("Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCheckbox("Online sellers");

        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Online sellers"),
                "Online sellers checkbox is not selected.");
        Assert.assertFalse(driver.getCurrentUrl().contains("online_sellers"),
                "URL should not be filtered by Online sellers (bug).");
        LOGGER.info("✅ Verified: Online sellers checkbox selection does not apply filter (bug).");
    }

    @Test(testName = "TC026_VerifyCombiningTwoCheckboxes")
    public void testCombiningTwoCheckboxes() {
        homePage.enterSearchKeyword("Programming");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCheckbox("Pro services");
        searchResultsPage.clickCheckbox("Local sellers");

        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Pro services"),
                "Pro services checkbox should be selected.");
        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Local sellers"),
                "Local sellers checkbox should be selected.");
        Assert.assertFalse(driver.getCurrentUrl().contains("pro_services") &&
                        driver.getCurrentUrl().contains("local_sellers"),
                "URL should not be filtered by both switches (bug).");
        LOGGER.info("✅ Verified: Combining two checkboxes does not apply filter (bug).");
    }

    @Test(testName = "TC027_VerifyCombiningThreeCheckboxes")
    public void testCombiningThreeCheckboxes() {
        homePage.enterSearchKeyword("Video");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickCheckbox("Online sellers");
        searchResultsPage.clickCheckbox("Pro services");
        searchResultsPage.clickCheckbox("Local sellers");

        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Online sellers"),
                "Online sellers checkbox should be selected.");
        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Pro services"),
                "Pro services checkbox should be selected.");
        Assert.assertTrue(searchResultsPage.isCheckboxSelected("Local sellers"),
                "Local sellers checkbox should be selected.");
        Assert.assertFalse(driver.getCurrentUrl().contains("online_sellers") &&
                        driver.getCurrentUrl().contains("pro_services") &&
                        driver.getCurrentUrl().contains("local_sellers"),
                "URL should not be filtered by all three switches (bug).");
        LOGGER.info("✅ Verified: Combining three checkboxes does not apply filter (bug).");
    }

    @Test(testName = "TC028_VerifySortByFunction")
    public void testVerifySortByFunction() {
        homePage.enterSearchKeyword("Graphic Design");
        homePage.clickSearchButton();

        searchResultsPage = new SearchResultsPage(driver);
        searchResultsPage.clickSortByDropdown();
        searchResultsPage.selectSortByOption("Best Selling");

        Assert.assertFalse(driver.getCurrentUrl().contains("sort=best-selling"),
                "URL should not show sort by 'Best Selling' (bug).");
        LOGGER.info("✅ Verified: Sort by function does not apply sorting (bug).");
    }
}
